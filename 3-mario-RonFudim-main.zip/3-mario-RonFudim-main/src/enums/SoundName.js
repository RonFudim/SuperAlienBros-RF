const SoundName = {
	Death: 'death',
	EmptyBlock: 'empty-block',
	Jump: 'jump',
	Kill: 'kill',
	Kill2: 'kill2',
	Music: 'music',
	PickUp: 'pick-up',
	Reveal: 'reveal',
};

export default SoundName;
