const SnailStateName = {
	Idle: 'idle',
	Moving: 'moving',
	Chasing: 'chasing',
	Dying: 'dying',
};

export default SnailStateName;
