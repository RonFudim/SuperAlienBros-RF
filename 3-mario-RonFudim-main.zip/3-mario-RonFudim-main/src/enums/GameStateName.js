const GameStateName = {
	Play: 'play',
	TitleScreen: 'title-screen',
};

export default GameStateName;
