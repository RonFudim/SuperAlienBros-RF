const PlayerStateName = {
	Idle: 'idle',
	Walking: 'walking',
	Jumping: 'jumping',
	Falling: 'falling',
	Dying: 'dying',
};

export default PlayerStateName;
