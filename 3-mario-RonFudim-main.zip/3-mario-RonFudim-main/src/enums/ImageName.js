const ImageName = {
	Background: 'background',
	Blocks: 'blocks',
	Bushes: 'bushes',
	Coin: 'coin',
	Flagpole: 'flagpoles',
	Character: 'character',
	BigCharacter: 'big-character',
	Creatures: 'creatures',
	Tiles: 'tiles',
	Toppers: 'toppers',
	PowerUps: 'power-ups'
};

export default ImageName;
