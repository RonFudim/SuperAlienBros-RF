const TileType = {
	Ground: 2,
	Empty: 4,
};

export default TileType;
